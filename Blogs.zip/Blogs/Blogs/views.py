#from django.http import HttpResponse
from django.shortcuts import render 

def Home(request):
    return render(request,'HomePage.html')
    # return HttpResponse('Homepage')

def About(request) :
    return render(request,'AboutUs.html')